sap.ui.define([
	"pg/kanban/controller/BaseController",
	"sap/ui/model/json/JSONModel",
	"pg/kanban/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"pg/kanban/utility/utilities",
	"sap/ui/comp/valuehelpdialog/ValueHelpDialog",
	"sap/ui/comp/filterbar/FilterBar",
	"sap/ui/core/Item",
	"sap/m/Token"
], function(BaseController, JSONModel, formatter, Filter, FilterOperator, utilities, ValueHelpDialog, FilterBar, Item, Token) {
	"use strict";

	return BaseController.extend("pg.kanban.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function() {
			var oViewModel,
				oResponsibleModel = new JSONModel(),
				iOriginalBusyDelay,
				oTable = this.byId("controlCycleSmartTable");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();

			this._oTable = oTable;
			this.oResponsiblePerson = null;

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");
			this.setModel(oResponsibleModel, "responsible");
			
			this.setWorklistRefreshInterval();

			this.byId("responsibleFilter").setEnableMultiLineMode(sap.ui.Device.system.phone);
			this.byId("controlCycleTable").setNoDataText(this.getResourceBundle().getText("tableNoDataText"));
			
			this.getRouter().getRoute("worklist").attachPatternMatched(this._onObjectMatched, this);
			
			this.getOwnerComponent().oWhenMetadataIsLoaded.then(function(){
				this.byId("supplyAreaConfiguration").setLabel(this.getResourceBundle().getText("SupplyArea"));
				this.byId("responsibleConfiguration").setLabel(this.getResourceBundle().getText("Responsible"));
			}.bind(this));
			
			sap.ui.getCore().getEventBus().subscribe("pg.kanban.EventBus", "refreshControlCycleList", this.search, this);
		},
		
		onExit: function(){
			sap.ui.getCore().getEventBus().unsubscribe("pg.kanban.EventBus", "refreshControlCycleList", this.search, this);	
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		onAfterRendering: function() {
			// if (document.cookie.indexOf("_walkthrough-introduction") < 0) {
			// 	utilities.generateWalkthrough(this);
			// }

		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function(oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Navigates back in the browser history, if the entry was created by this app.
		 * If not, it navigates to the Fiori Launchpad home page.
		 * @public
		 */
		onNavBack: function() {
			var oHistory = sap.ui.core.routing.History.getInstance(),
				sPreviousHash = oHistory.getPreviousHash(),
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			if (sPreviousHash !== undefined) {
				// The history contains a previous entry
				history.go(-1);
			} else {
				// Navigate back to FLP home
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#"
					}
				});
			}
		},

		/**
		 * When the SmartTable has been initialised with metadata. Save
		 * the column titles for later reuse as generic column titles.
		 * @public
		 */
		onSmartTableInitialised: function(oEvent) {
			var oTable = oEvent.getSource().getTable();
			var aColumns = oTable.getColumns();
			var oColumnCustomData;
			var oResourceBundle = this.getResourceBundle();
			for (var i = 0; i < aColumns.length; i++) {
				oColumnCustomData = utilities.getColumnDataByColumn(aColumns[i]);
				switch (oColumnCustomData.columnKey) {
					case "ControlCycleID":
						aColumns[i].setVisible(false);
						break;
					case "MaterialNo":
						aColumns[i].setVisible(false);
						// aColumns[i].getHeader().setText(oResourceBundle.getText("Material"));
						// aColumns[i].setOrder(2);
						break;
					case "Material":
						aColumns[i].setVisible(true);
						// aColumns[i].getHeader().setText(oResourceBundle.getText("Material"));
						aColumns[i].setOrder(2);
						break;
					case "Plant":
						aColumns[i].setVisible(false);
						break;
					case "SupplyArea":
						aColumns[i].setVisible(true);
						aColumns[i].getHeader().setText(oResourceBundle.getText("SupplyArea"));
						aColumns[i].setOrder(0);
						break;
					case "Responsible":
						aColumns[i].setVisible(true);
						aColumns[i].getHeader().setText(oResourceBundle.getText("Responsible"));
						aColumns[i].setOrder(1);
						break;
					case "StoringPos":
						aColumns[i].setVisible(false);
						break;
					case "KanbanOverview":
						aColumns[i].setVisible(true);
						aColumns[i].setOrder(3);
						break;
					default:
						aColumns[i].setVisible(false);
						break;
				}
			}
		},
		
		onTableDataReceived: function(){
			this.byId("controlCycleTable").setShowOverlay(false);
		},

		onBeforeRebindTable: function(oEvent) {
			var mBindingParams = oEvent.getParameter("bindingParams");
			var aSelectedSAKeys = this.byId("supplyAreaFilter").getSelectedKeys();
			var aSelectedResKeys = this.byId("responsibleFilter").getTokens();
			var aFilters = [];
			for (var i = 0; i < aSelectedSAKeys.length; i++) {
				aFilters.push(new Filter({
					path: "SupplyArea",
					operator: FilterOperator.EQ,
					value1: aSelectedSAKeys[i]
				}));
			}
			for (var j = 0; j < aSelectedResKeys.length; j++) {
				aFilters.push(new Filter({
					path: "Responsible",
					operator: FilterOperator.EQ,
					value1: aSelectedResKeys[j].getKey()
				}));
			}
			if (aFilters.length > 0) {
				this._addFilters(mBindingParams, aFilters);
			}
			//add Plant field request to select parameter
			mBindingParams.parameters.select += ",Plant,ControlCycleID,MaterialNo,StoringPos";
		},

		onSupplyAreaSlecteionFinish: function() {
			this.search();
		},

		onResonsibleChange: function() {
			this.search();
		},

		onResponsileValueHelpRequested: function() {
			var handleValueHelp = function(oData, response, oController){
				var oValueHelpDialog = new ValueHelpDialog({
						basicSearchText: oController.byId("responsibleFilter").getValue(),
						title: oController.getResourceBundle().getText("Responsible"),
						supportMultiselect: true,
						supportRanges: false,
						// supportRangesOnly: false,
						key: "Dispo",
						descriptionKey: "Dsnam",
						stretch: sap.ui.Device.system.phone,

						ok: function(oControlEvent) {
							oController.byId("responsibleFilter").setTokens(oControlEvent.getParameter("tokens"));
							oValueHelpDialog.close();
						}.bind(oController),

						cancel: function(oControlEvent) {
							oValueHelpDialog.close();
						},

						afterClose: function() {
							oValueHelpDialog.destroy();
						}
					});
					var oTable = oValueHelpDialog.getTable();
					var oColModel = new sap.ui.model.json.JSONModel();
					oColModel.setData({
						cols: [{
							label: oController.getResourceBundle().getText("Dispo"),
							template: "Dispo"
						}, {
							label: oController.getResourceBundle().getText("Dsnam"),
							template: "Dsnam"
						}]
					});
					oTable.setModel(oColModel, "columns");
					var oRowsModel = new sap.ui.model.json.JSONModel();
					oRowsModel.setData(oData.results);
					oTable.setModel(oRowsModel);
					if (oValueHelpDialog.getTable().bindRows) {
						oValueHelpDialog.getTable().bindRows("/");
					}
					if (oValueHelpDialog.getTable().bindItems) {
						oTable.bindAggregation("items", "/", function(sId, oContext) {
							var aCols = oTable.getModel("columns").getData().cols;

							return new sap.m.ColumnListItem({
								cells: aCols.map(function(column) {
									var colname = column.template;
									return new sap.m.Label({
										text: "{" + colname + "}"
									});
								})
							});
						});
					}
					oValueHelpDialog.setRangeKeyFields([{
						label: oController.getResourceBundle().getText("Dispo"),
						key: "Dispo"
					}]);

					oValueHelpDialog.setTokens(oController.byId("responsibleFilter").getTokens());

					if (oController.byId("responsibleFilter").$().closest(".sapUiSizeCompact").length > 0) {
						oValueHelpDialog.addStyleClass("sapUiSizeCompact");
					} else {
						oValueHelpDialog.addStyleClass("sapUiSizeCozy");
					}

					oValueHelpDialog.open();
					oValueHelpDialog.update();	
			};
			if(this.oResponsiblePerson){
				handleValueHelp(this.oResponsiblePerson, null, this);	
			} else {
				this.getView().setBusy(true);
				this.getModel().read("/ResponsibleSet", {
					success: function(oData, response) {
						this.oResponsiblePerson = oData;
						handleValueHelp(oData, response, this);	
						this.getView().setBusy(false);
					}.bind(this),
					error: function(oError) {
						this.getView().setBusy(false);
					}.bind(this)
				});
			}
		},
		
		supplyAreaFactory: function(sID, oContext){
			var oItem;
			var oData = oContext.getObject();
			oItem = new Item({
				key:oData.SupplyAreaID, 
				text:oData.SupplyAreaID + "--" + oData.SupplyAreaDesc
			});
			if(oData.SupplyAreaDefault === "X"){
				this.byId("supplyAreaFilter").addSelectedItem(oItem);
				this.search();
			}
			return oItem;
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function(oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("ControlCycleID")
			});
		},
		
		/**
		 * Bind User and Plant
		 * @private
		 */
		_onObjectMatched: function(oEvent){
			this.getModel().read("/BasicInfoSet", {
				success: function(oData, response){
					if(oData.results.length > 0){
						this.byId("userText").setText(oData.results[0].UserName);
						this.byId("plantText").setText(oData.results[0].Plant);
						this.byId("systemText").setText(oData.results[0].SystemID);
					}
				}.bind(this),
				error: function(oError){
					
				}.bind(this)
			});
			if(this.oResponsiblePerson){
        		this.byId("smartFilterBar").setBusy(false);
        		return;
    		}
			this.byId("smartFilterBar").setBusy(true);
			this.getModel().read("/ResponsibleSet", {
				success: function(oData, response) {
					this.oResponsiblePerson = oData;
					//set default value
					for(var i = 0; i < oData.results.length; i++){
						if(oData.results[i].Default === "X"){
							this.byId("responsibleFilter").addToken(new Token({key:oData.results[i].Dispo, text:oData.results[i].Dsnam}));
							this.search();
						}
					}
					this.byId("smartFilterBar").setBusy(false);
				}.bind(this),
				error: function(oError) {
					this.byId("smartFilterBar").setBusy(false);
				}.bind(this)
			});
		},

		/**
		 * Adds filters to the binding parameters.
		 * @param {map} mBindingParams binding parameters or array thereof
		 * @param {sap.ui.model.Filter} vFilters filter or filters to add
		 * @private
		 */
		_addFilters: function(mBindingParams, vFilters) {
			var aFilters = vFilters;
			if (!aFilters.length) {
				aFilters = [aFilters];
			}
			for (var i = 0; i < aFilters.length; i++) {
				var oFilter = aFilters[i];
				mBindingParams.filters.push(oFilter);
			}
		},

		/* =========================================================== */
		/* public methods                                            */
		/* =========================================================== */

		generateKanbanOverviewBar: function(sId, oContext) {
			// var oBindObject = oContext.getObject();
			// return utilities.getStackedBarMicroChartBar(oBindObject.KanbanNum, oBindObject.KanbanStatus);
			var oBindObject = oContext.getObject();
			return utilities.getMessageStrip(oBindObject.KanbanNum, oBindObject.KanbanStatus);
		},

		search: function() {
			this.byId("smartFilterBar").search(true);
		},
		
		setWorklistRefreshInterval: function(){
			this.intervalTrigger = new sap.ui.core.IntervalTrigger(120000);
			this.intervalTrigger.addListener(function(){
				this.search();
			}, this);
		}
	});

});