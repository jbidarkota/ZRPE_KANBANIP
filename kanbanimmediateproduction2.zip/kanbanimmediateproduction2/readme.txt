==== WELCOME ====

This is your copy of the UI5 Worklist Application Template.

Standalone runnable files (*.html) are located in the test-folder

This application is ready for client-side build in the SAP Web IDE and deployment to ABAP/HCP repositories

Documentation of all template-app features can be found in the SAPUI5 demokit here:
https://sapui5.hana.ondemand.com/#docs/guide/a460a7348a6c431a8bd967ab9fb8d918.html

=== Enjoy development! ===     